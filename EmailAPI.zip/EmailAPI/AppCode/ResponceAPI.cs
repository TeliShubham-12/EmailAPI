

namespace emService.AppCode
{
public class ResponseAPI
    {
        public object data;
        public string message;
        public string status;

       // public ResponseAPI();
    }
}